<?php
    define('IN_SYS', true);
    require_once ("core.php");
    $title = $title . ' - ' . I18N('login');
?>
<?php include ("include/header.php"); ?>

<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo I18N('please_login'); ?></h3>
        </div>
        <div class="panel-body">
            <form class="form-group form-horizontal form-account" role="form" action="//cpanel.<?=$domain?>/login.php" method="post" name="login">
                <div class="form-group">
                    <input type="text" name="uname" class="form-control" placeholder="<?php echo I18N('input_username'); ?>" required autofocus autocomplete="off">
                </div>
                <div class="form-group">
                    <input type="password" name="passwd" class="form-control" placeholder="<?php echo I18N('input_password'); ?>" required autocomplete="off">
                </div>
 <div class="form-group">
<input type="hidden" class="form-control" size="1" value="Georgian" name="language">
             </div>
                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-primary btn-block"><?php echo I18N('login'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include ("include/footer.php"); ?>
