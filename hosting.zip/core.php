<?php
if (!defined('IN_SYS')) {
    header("Location: index.php");
    exit;
}
$ROOT = __DIR__;

$domain = "georgia.eu.org";
$brandName = "www.georgia.eu.org";
$iFastNetAff = 28868;
$CopyRightYear = "" . date("Y");
$title = "უფასო ვებ ჰოსტინგი";
$title_s = "უფასო ვებ ჰოსტინგი";
$author = 'მერაბი';
$description = "უფასო ვებ ჰოსტინგი PHP და MySQL";

include_once "{$ROOT}/lib/language.php";
