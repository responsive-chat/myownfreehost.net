<?php
if (!defined('IN_SYS')) {
    header("Location: index.php");
    exit;
}
$ROOT = __DIR__;

$domain = "bmulebi.com";
$brandName = "bmulebi.com";
$iFastNetAff = 29306;
$CopyRightYear = "" . date("Y");
$title = "უფასო ვებ ჰოსტინგი";
$title_s = "უფასო ვებ ჰოსტინგი";
$author = 'მერაბი';
$description = "უფასო ვებ ჰოსტინგი PHP და MySQL";

include_once "{$ROOT}/lib/language.php";
