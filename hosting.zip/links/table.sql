-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql112.bmulebi.com
-- Generation Time: Jun 12, 2022 at 03:25 PM
-- Server version: 10.3.27-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bmule_31895286_links`
--

-- --------------------------------------------------------

--
-- Table structure for table `MyCategories`
--

CREATE TABLE `MyCategories` (
  `CatID` bigint(21) NOT NULL,
  `CatName` varchar(32) NOT NULL,
  `CatParent` bigint(21) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MyCategories`
--

INSERT INTO `MyCategories` (`CatID`, `CatName`, `CatParent`) VALUES
(1, 'áƒ‘áƒšáƒáƒ’áƒ”áƒ‘áƒ˜', NULL),
(2, 'áƒ¡áƒ”áƒ áƒ•áƒ˜áƒ¡áƒ”áƒ‘áƒ˜', NULL),
(3, 'áƒ˜áƒœáƒ¢áƒ”áƒ áƒœáƒ”áƒ¢áƒ˜', NULL),
(4, 'áƒ™áƒáƒ›áƒžáƒ˜áƒ£áƒ¢áƒ”áƒ áƒ˜', NULL),
(5, 'áƒ¡áƒ›áƒáƒ áƒ¢áƒ¤áƒáƒœáƒ˜', NULL),
(6, 'áƒ’áƒáƒ“áƒ›áƒáƒ¬áƒ”áƒ áƒ', NULL),
(7, 'áƒ’áƒáƒ¡áƒáƒ áƒ—áƒáƒ‘áƒ˜', NULL),
(8, 'áƒªáƒœáƒáƒ‘áƒáƒ áƒ˜', NULL),
(9, 'áƒ áƒ”áƒšáƒ˜áƒ’áƒ˜áƒ', NULL),
(10, 'áƒžáƒáƒšáƒ˜áƒ¢áƒ˜áƒ™áƒ', NULL),
(11, 'áƒ›áƒ”áƒªáƒœáƒ˜áƒ”áƒ áƒ”áƒ‘áƒ', NULL),
(12, 'áƒ’áƒáƒœáƒáƒ—áƒšáƒ”áƒ‘áƒ', NULL),
(13, 'áƒ™áƒ£áƒšáƒ¢áƒ£áƒ áƒ', NULL),
(14, 'áƒ›áƒáƒ’áƒ–áƒáƒ£áƒ áƒáƒ‘áƒ', NULL),
(15, 'áƒ›áƒ£áƒ¡áƒ˜áƒ™áƒ”áƒ‘áƒ˜', NULL),
(16, 'áƒ•áƒ˜áƒ“áƒ”áƒáƒ”áƒ‘áƒ˜', NULL),
(17, 'áƒ—áƒáƒ›áƒáƒ¨áƒ”áƒ‘áƒ˜', NULL),
(18, 'áƒžáƒ áƒáƒ’áƒ áƒáƒ›áƒ”áƒ‘áƒ˜', NULL),
(19, 'áƒ›áƒáƒ¡áƒ›áƒ”áƒ“áƒ˜áƒ', NULL),
(21, 'áƒ™áƒáƒ›áƒžáƒáƒœáƒ˜áƒ', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `MyLinks`
--

CREATE TABLE `MyLinks` (
  `LinkID` bigint(21) NOT NULL,
  `CatID` bigint(21) NOT NULL,
  `Url` varchar(255) NOT NULL,
  `LinkName` varchar(64) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Approved` tinyint(8) DEFAULT 0,
  `SubmitName` varchar(64) NOT NULL,
  `SubmitEmail` varchar(64) NOT NULL,
  `SubmitDate` bigint(21) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `MyCategories`
--
ALTER TABLE `MyCategories`
  ADD PRIMARY KEY (`CatID`),
  ADD UNIQUE KEY `CatName` (`CatName`);

--
-- Indexes for table `MyLinks`
--
ALTER TABLE `MyLinks`
  ADD PRIMARY KEY (`LinkID`),
  ADD UNIQUE KEY `Url` (`Url`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `MyCategories`
--
ALTER TABLE `MyCategories`
  MODIFY `CatID` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `MyLinks`
--
ALTER TABLE `MyLinks`
  MODIFY `LinkID` bigint(21) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
