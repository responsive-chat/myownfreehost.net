<?php
$HEADER_FILE = "header.html";      // Path to the template file
$FOOTER_FILE = "footer.html";      // Path to the template file
$SITE_NAME = "bmulebi.com";               // Title of the site (keep short)
$ADMIN_MODE = true;                  // Set true for admin version
$SEE_ALL_SUBMISSIONS = true;          // Set false to show submissions in this category only
$SITE_URL = "http://www.bmulebi.com";  // Set real URL of site
$SITE_DIR = "/links/";      // Appended to SITE_URL for complete address
$FULL_ADMIN_ACCESS = true;            // True to allow admin to create categories
$TOP_CAT_NAME = "&#9873; რჩეულები";                // Name of the top "category"
$ENABLE_EMAIL = "off";		      // Set to on to enable email support
$ADMIN_EMAIL = "merab.mazmanian@gmail.com"; // Admin email address used for new links
$SMTP_HOSTNAME = "www.bmulebi.com";
$SMTP_LOCALHOST = "localhost";
$AUTOAPPROVE = false;                 // True to automatically approve submissions
$REQUIRE_SUBMIT_EMAIL = false;        // True to require email for any submissions
$SQL_CAT_TBL = "MyCategories";        // MySQL table name for the categories table
$SQL_LNK_TBL = "MyLinks";             // MySQL table name for the links table
date_default_timezone_set('Asia/Tbilisi');
$ADMIN_USER = "admin";                   // Username to enter admin mode
$ADMIN_PASS = "12345678";                   // Password to enter admin mode
$ADMIN_COOKIE = "qwetreasdgfd";         // Secret cookie to signal admin mode
$SQL_DBASE = "bmule_31895286_links";               // Set name of database to use
$SQL_USER = "bmule_31895286";                  // Set database username
$SQL_PASS = "regeneracia2234";                  // Set database R/W password
$SQL_SERVER = "sql112.bmulebi.com";            // Set server name
$ANYONE_SUGGEST = "true";                  // Allow anyone to suggest links
?>
