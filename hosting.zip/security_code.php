<?php
define('IN_SYS', true);
require_once ("core.php");
$security_id = $_GET["id"];

header('Content-Type:image/png');
$url = "http://order.georgia.eu.org/image.php?id=".$security_id."";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0);
curl_setopt($ch, CURLOPT_TIMEOUT,0);
curl_setopt($ch, CURLOPT_NOBODY, false);
$str = curl_exec($ch);
curl_close($ch);
